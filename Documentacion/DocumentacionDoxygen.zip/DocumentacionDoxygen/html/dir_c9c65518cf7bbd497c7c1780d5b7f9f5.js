var dir_c9c65518cf7bbd497c7c1780d5b7f9f5 =
[
    [ ".NETFramework,Version=v4.8.AssemblyAttributes.cs", "_8_n_e_t_framework_00_version_0av4_88_8_assembly_attributes_8cs.html", null ]
];