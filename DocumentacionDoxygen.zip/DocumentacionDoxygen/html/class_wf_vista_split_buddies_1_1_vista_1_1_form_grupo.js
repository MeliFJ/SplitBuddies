var class_wf_vista_split_buddies_1_1_vista_1_1_form_grupo =
[
    [ "FormGrupo", "class_wf_vista_split_buddies_1_1_vista_1_1_form_grupo.html#ac14fb0223262194702e8c7071b96265d", null ],
    [ "Dispose", "class_wf_vista_split_buddies_1_1_vista_1_1_form_grupo.html#ac8bf7e0d8ca98052ccecfc8abb8ff1da", null ]
];