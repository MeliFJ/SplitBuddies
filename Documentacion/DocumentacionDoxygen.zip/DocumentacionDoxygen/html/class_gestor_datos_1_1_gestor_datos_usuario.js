var class_gestor_datos_1_1_gestor_datos_usuario =
[
    [ "BuscarUsuario", "class_gestor_datos_1_1_gestor_datos_usuario.html#ada20f9cb00e5ce0a97fcb3df4b9dced7", null ],
    [ "CargarUsuarioPorGrupos", "class_gestor_datos_1_1_gestor_datos_usuario.html#a1b8ed09fc12c383d2ac51bc837cc8d32", null ],
    [ "CargarUsuarios", "class_gestor_datos_1_1_gestor_datos_usuario.html#a8a8130db60a14e7df6c87aacc0782645", null ],
    [ "CargarUsuariosPorGastoId", "class_gestor_datos_1_1_gestor_datos_usuario.html#a142222e6b17df10a81e25b89bf690ee5", null ],
    [ "GuardarUsuario", "class_gestor_datos_1_1_gestor_datos_usuario.html#aa732d41e0e9e4bafefb1a99aa5b0e168", null ]
];