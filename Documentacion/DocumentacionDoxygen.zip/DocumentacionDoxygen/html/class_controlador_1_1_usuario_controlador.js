var class_controlador_1_1_usuario_controlador =
[
    [ "BuscarUsuario", "class_controlador_1_1_usuario_controlador.html#ace8673552c52c864172c6ee1be342c4a", null ],
    [ "CargarUsuarioPorGastoId", "class_controlador_1_1_usuario_controlador.html#afcddb6d1c4c93c5477f4854fa731bdbb", null ],
    [ "CargarUsuarioPorGrupos", "class_controlador_1_1_usuario_controlador.html#ae03a32b4e959bbd364589531c18f4e43", null ],
    [ "CargarUsuarios", "class_controlador_1_1_usuario_controlador.html#a2ca8bc189bfa66059b03374d48f52057", null ],
    [ "GuardaUsuario", "class_controlador_1_1_usuario_controlador.html#a94d72df5936778b165eec7dabe2fde94", null ]
];