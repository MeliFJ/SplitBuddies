var _gestor_datos_gastos_8cs =
[
    [ "GestorDatos.GestorDatosGastos", "class_gestor_datos_1_1_gestor_datos_gastos.html", "class_gestor_datos_1_1_gestor_datos_gastos" ]
];