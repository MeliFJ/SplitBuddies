var searchData=
[
  ['form1_0',['Form1',['../class_wf_vista_split_buddies_1_1_form1.html#ac970d7d28f0f80c9e265609b5b0cd4d0',1,'WfVistaSplitBuddies::Form1']]],
  ['formgastos_1',['FormGastos',['../class_wf_vista_split_buddies_1_1_vista_1_1_form_gastos.html#a0324949f4e1b7d19eaf257d0adeae66f',1,'WfVistaSplitBuddies.Vista.FormGastos.FormGastos(Grupo grupo, List&lt; Usuario &gt; integrantesDelGrupo, Usuario usuario, IGastosControlador gastosControlador, IGrupoControlador grupoControlador)'],['../class_wf_vista_split_buddies_1_1_vista_1_1_form_gastos.html#ad04900c69db8b7db1f825f3bcffb09ba',1,'WfVistaSplitBuddies.Vista.FormGastos.FormGastos(Grupo grupo, List&lt; Usuario &gt; integrantesDelGrupo, Usuario usuario, IGastosControlador gastosControlador, IGrupoControlador grupoControlador, bool esModificar)']]],
  ['formgrupo_2',['FormGrupo',['../class_wf_vista_split_buddies_1_1_vista_1_1_form_grupo.html#ac14fb0223262194702e8c7071b96265d',1,'WfVistaSplitBuddies::Vista::FormGrupo']]],
  ['formreporte_3',['FormReporte',['../class_wf_vista_split_buddies_1_1_form_reporte.html#ad5d3107a4e4f6ad68e63832fdd87cbe6',1,'WfVistaSplitBuddies::FormReporte']]],
  ['formresumengastosporusuario_4',['FormResumenGastosPorUsuario',['../class_wf_vista_split_buddies_1_1_form_resumen_gastos_por_usuario.html#ac2fb9f52cede5ec76bf6a6e3151e17cb',1,'WfVistaSplitBuddies::FormResumenGastosPorUsuario']]]
];
