var _form1_8_designer_8cs =
[
    [ "WfVistaSplitBuddies.Form1", "class_wf_vista_split_buddies_1_1_form1.html", "class_wf_vista_split_buddies_1_1_form1" ]
];