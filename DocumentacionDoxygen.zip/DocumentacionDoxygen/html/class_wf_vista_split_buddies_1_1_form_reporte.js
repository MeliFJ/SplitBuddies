var class_wf_vista_split_buddies_1_1_form_reporte =
[
    [ "FormReporte", "class_wf_vista_split_buddies_1_1_form_reporte.html#ad5d3107a4e4f6ad68e63832fdd87cbe6", null ],
    [ "Dispose", "class_wf_vista_split_buddies_1_1_form_reporte.html#ae1d168f9fd1b476c60097425c10c66f2", null ]
];