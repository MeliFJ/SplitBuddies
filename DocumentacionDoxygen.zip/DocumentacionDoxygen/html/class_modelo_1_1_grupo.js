var class_modelo_1_1_grupo =
[
    [ "Grupo", "class_modelo_1_1_grupo.html#a0e27d8eab788e3212ff0ae4a46800692", null ],
    [ "Grupo", "class_modelo_1_1_grupo.html#a82c0ca765e84951a7d8a6c57a978ff38", null ],
    [ "Grupo", "class_modelo_1_1_grupo.html#a3374205c17febbd75e7aee51e7571587", null ],
    [ "CreadorId", "class_modelo_1_1_grupo.html#a74ec02452b96df92493a78d7f83c4bc7", null ],
    [ "Id", "class_modelo_1_1_grupo.html#a54af14e2463b7afab0a782b2671b0eed", null ],
    [ "Nombre", "class_modelo_1_1_grupo.html#adbec85075c91dbe9d81a005439ad8ac4", null ],
    [ "NombreLogo", "class_modelo_1_1_grupo.html#a127a9c6cd70509e3b5590231c4c7ba7c", null ]
];