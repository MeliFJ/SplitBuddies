var _gestor_datos_base_8cs =
[
    [ "GestorDatos.GestorDatosBase", "class_gestor_datos_1_1_gestor_datos_base.html", null ]
];