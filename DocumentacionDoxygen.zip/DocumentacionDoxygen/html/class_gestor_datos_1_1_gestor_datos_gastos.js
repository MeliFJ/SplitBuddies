var class_gestor_datos_1_1_gestor_datos_gastos =
[
    [ "ActualizarGasto", "class_gestor_datos_1_1_gestor_datos_gastos.html#a45707d2eb393e4a063487c0de2bf4dc8", null ],
    [ "CargarGastos", "class_gestor_datos_1_1_gestor_datos_gastos.html#a636404c54839c4697a051070b360b71b", null ],
    [ "CargarGastosXGrupo", "class_gestor_datos_1_1_gestor_datos_gastos.html#a1e6650d7127f7a5804bb47f594cfe8c4", null ],
    [ "ConsultarGastosPorGrupoyUsuario", "class_gestor_datos_1_1_gestor_datos_gastos.html#a075f41ea8b389a448a9f17992925e212", null ],
    [ "ConsultarGastosPorUsuario", "class_gestor_datos_1_1_gestor_datos_gastos.html#a91bd4826d5bb4ae674dbfff7475e2df3", null ],
    [ "EliminarGasto", "class_gestor_datos_1_1_gestor_datos_gastos.html#a8b0b1c4a4737d0428fb0c46a90408854", null ],
    [ "GuardarGasto", "class_gestor_datos_1_1_gestor_datos_gastos.html#a84e54d3f2fe909fd4393661e5591c315", null ],
    [ "guardarGrupoGasto", "class_gestor_datos_1_1_gestor_datos_gastos.html#a149e2dcc3a6b45dc86a7b73703b1faf7", null ],
    [ "ObtenerReportePorUsuario", "class_gestor_datos_1_1_gestor_datos_gastos.html#af85052c2032c84e7f6b0ca549a89edbb", null ],
    [ "List< RelacionGrupoGasto >", "class_gestor_datos_1_1_gestor_datos_gastos.html#ae403ff819ec027cdda8e147104bef974", null ],
    [ "List< RelacionUsuarioGasto >", "class_gestor_datos_1_1_gestor_datos_gastos.html#ad04ab8a2a80fd595bd1bb545a0151a69", null ]
];