var searchData=
[
  ['fechaseleccionada_0',['FechaSeleccionada',['../class_modelo_1_1_gasto.html#a5bab196086fda2b9753ec3ebb7977bf4',1,'Modelo::Gasto']]]
];
