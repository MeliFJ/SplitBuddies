var class_controlador_1_1_gastos_controlador =
[
    [ "GastosControlador", "class_controlador_1_1_gastos_controlador.html#a38ecc48e7377394689b007012025ff9b", null ],
    [ "ActualizarGasto", "class_controlador_1_1_gastos_controlador.html#ac70d281005b674d245044f3d7c0c012f", null ],
    [ "CargarGastoPorGrupo", "class_controlador_1_1_gastos_controlador.html#a1a5fc0776434ad9ae9af20081d12ca2d", null ],
    [ "CargarGastoPorUsuarioEnGrupo", "class_controlador_1_1_gastos_controlador.html#a9126c9d46e7c248db16ea68fe48c4371", null ],
    [ "ConsultarGastosPorGrupoyUsuario", "class_controlador_1_1_gastos_controlador.html#ada9749a3ad2fdaaa03021ec6f32f9c97", null ],
    [ "ConsultarGastosPorUsuario", "class_controlador_1_1_gastos_controlador.html#a9ab0b4c3078c4ee14e3b5e605332972a", null ],
    [ "EliminarGasto", "class_controlador_1_1_gastos_controlador.html#abda71fd2c3a12b091fac44d32b47d838", null ],
    [ "GenerarReportePorAnno", "class_controlador_1_1_gastos_controlador.html#a5f7875a95210fb6846bd3f3220648588", null ],
    [ "GenerarReportePorFechas", "class_controlador_1_1_gastos_controlador.html#aed2ca4529b5459704ba79a17b1f7eb89", null ],
    [ "GenerarReportePorMes", "class_controlador_1_1_gastos_controlador.html#a780b633c5a115669b5516632c0085db2", null ],
    [ "guardarGasto", "class_controlador_1_1_gastos_controlador.html#ae0740c911ec86d446fd1812c979e9310", null ]
];