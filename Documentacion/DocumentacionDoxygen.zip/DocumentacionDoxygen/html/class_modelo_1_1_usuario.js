var class_modelo_1_1_usuario =
[
    [ "Usuario", "class_modelo_1_1_usuario.html#ac067c42becbdac2cb8205f3810c01d51", null ],
    [ "Equals", "class_modelo_1_1_usuario.html#a4e1e22fcf0515a19ebaec4fbf84f7676", null ],
    [ "GetHashCode", "class_modelo_1_1_usuario.html#ab4e850a0a043b6e927bb748e95ce49a2", null ],
    [ "ToString", "class_modelo_1_1_usuario.html#a143a3696fe3effdef8dbcbe2fbf73e13", null ],
    [ "Apellido", "class_modelo_1_1_usuario.html#ac4238e02dd4d03760f62759fb9d1acc7", null ],
    [ "Identificacion", "class_modelo_1_1_usuario.html#a235419bd65ed45bc7906ba5ba106f7cb", null ],
    [ "Nombre", "class_modelo_1_1_usuario.html#a8b88f6d6db37bc2e3ec337dd1a2b0d78", null ],
    [ "Password", "class_modelo_1_1_usuario.html#a014f58d493d0a17d50b42c914ca91c6d", null ]
];