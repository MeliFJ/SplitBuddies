var class_modelo_1_1_relacion_usuario_grupo =
[
    [ "RelacionUsuarioGrupo", "class_modelo_1_1_relacion_usuario_grupo.html#a178817aa2565c3d71aac24b16920e1dd", null ],
    [ "RelacionUsuarioGrupo", "class_modelo_1_1_relacion_usuario_grupo.html#a21459d808e90d156b46c00c9291b4738", null ],
    [ "GrupoId", "class_modelo_1_1_relacion_usuario_grupo.html#a0c83057df59c5c1b178dd1618268dfdb", null ],
    [ "UsuarioId", "class_modelo_1_1_relacion_usuario_grupo.html#a160c7d5f648aefbca5d9a2272f723c01", null ]
];