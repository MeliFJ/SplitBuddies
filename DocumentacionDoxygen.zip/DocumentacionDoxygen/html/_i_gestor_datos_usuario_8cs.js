var _i_gestor_datos_usuario_8cs =
[
    [ "GestorDatos.Interfaces.IGestorDatosUsuario", "interface_gestor_datos_1_1_interfaces_1_1_i_gestor_datos_usuario.html", "interface_gestor_datos_1_1_interfaces_1_1_i_gestor_datos_usuario" ]
];