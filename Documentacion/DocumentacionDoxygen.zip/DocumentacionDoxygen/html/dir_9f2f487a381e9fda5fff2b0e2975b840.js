var dir_9f2f487a381e9fda5fff2b0e2975b840 =
[
    [ "AssemblyInfo.cs", "_wf_vista_split_buddies_2_properties_2_assembly_info_8cs.html", null ],
    [ "Resources.Designer.cs", "_resources_8_designer_8cs.html", null ],
    [ "Settings.Designer.cs", "_settings_8_designer_8cs.html", null ]
];