var _reporte_8cs =
[
    [ "Modelo.Reporte", "class_modelo_1_1_reporte.html", "class_modelo_1_1_reporte" ]
];