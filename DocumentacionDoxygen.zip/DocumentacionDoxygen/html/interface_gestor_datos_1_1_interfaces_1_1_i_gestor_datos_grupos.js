var interface_gestor_datos_1_1_interfaces_1_1_i_gestor_datos_grupos =
[
    [ "CargarGrupos", "interface_gestor_datos_1_1_interfaces_1_1_i_gestor_datos_grupos.html#a2c1bcb65ef25a7924950b61da59a3ca8", null ],
    [ "CargarGruposPorUsuario", "interface_gestor_datos_1_1_interfaces_1_1_i_gestor_datos_grupos.html#a58d266c6248c0c902f75fc3cec5feb78", null ],
    [ "CargarUsuarioGrupos", "interface_gestor_datos_1_1_interfaces_1_1_i_gestor_datos_grupos.html#a34645ef60edb47fe91deadb4416689aa", null ],
    [ "EsNombreGrupoUnico", "interface_gestor_datos_1_1_interfaces_1_1_i_gestor_datos_grupos.html#a76661f178e03f5a1d6799402c71dfa1b", null ],
    [ "GuardarGrupos", "interface_gestor_datos_1_1_interfaces_1_1_i_gestor_datos_grupos.html#a40e94c2e8f2ac488607de487aeac498c", null ],
    [ "GuardarUsuarioGrupo", "interface_gestor_datos_1_1_interfaces_1_1_i_gestor_datos_grupos.html#a44877c75bc0f0af076227378c33ed2bf", null ]
];