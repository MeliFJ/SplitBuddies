var interface_controlador_1_1_interfaces_1_1_i_usuario_controlador =
[
    [ "BuscarUsuario", "interface_controlador_1_1_interfaces_1_1_i_usuario_controlador.html#a7dff73ef5c68b16636ecefa2b66c64a9", null ],
    [ "CargarUsuarioPorGastoId", "interface_controlador_1_1_interfaces_1_1_i_usuario_controlador.html#ac51c9752d96476667bfe16fafc74eb77", null ],
    [ "CargarUsuarioPorGrupos", "interface_controlador_1_1_interfaces_1_1_i_usuario_controlador.html#a975f872887ad09d054722dc479cf39b9", null ],
    [ "CargarUsuarios", "interface_controlador_1_1_interfaces_1_1_i_usuario_controlador.html#a05bdc9871b3fb596bef677ad9bbf6e0d", null ],
    [ "GuardaUsuario", "interface_controlador_1_1_interfaces_1_1_i_usuario_controlador.html#ae40c777d6294c05ec8d584c6125f74d0", null ]
];