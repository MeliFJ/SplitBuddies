var _i_gestor_datos_gastos_8cs =
[
    [ "GestorDatos.Interfaces.IGestorDatosGastos", "interface_gestor_datos_1_1_interfaces_1_1_i_gestor_datos_gastos.html", "interface_gestor_datos_1_1_interfaces_1_1_i_gestor_datos_gastos" ]
];