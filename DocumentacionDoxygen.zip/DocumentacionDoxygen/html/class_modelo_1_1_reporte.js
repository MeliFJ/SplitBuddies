var class_modelo_1_1_reporte =
[
    [ "Reporte", "class_modelo_1_1_reporte.html#ace5e683108031eaf1f10fbdcae8423c2", null ],
    [ "Reporte", "class_modelo_1_1_reporte.html#a9b9c7d455c611ab86d47f4dbcf768716", null ],
    [ "Deuda", "class_modelo_1_1_reporte.html#ad36f471addd1c30ba8c25c8d3bae4fb6", null ],
    [ "Disponible", "class_modelo_1_1_reporte.html#af442ebf1a0317289460c32f14afedcb6", null ],
    [ "GastoTotal", "class_modelo_1_1_reporte.html#a5dbd25aa70cceef313280db206ff3ffb", null ]
];