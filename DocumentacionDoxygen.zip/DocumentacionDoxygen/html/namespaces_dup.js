var namespaces_dup =
[
    [ "Controlador", "namespace_controlador.html", "namespace_controlador" ],
    [ "GestorDatos", "namespace_gestor_datos.html", "namespace_gestor_datos" ],
    [ "Modelo", "namespace_modelo.html", "namespace_modelo" ],
    [ "WfVistaSplitBuddies", "namespace_wf_vista_split_buddies.html", "namespace_wf_vista_split_buddies" ]
];