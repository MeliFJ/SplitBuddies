var searchData=
[
  ['saldousuario_0',['SaldoUsuario',['../class_modelo_1_1_gasto_grupo_usuario.html#af8a86e1b9d92a8571817f302eea67b0f',1,'Modelo::GastoGrupoUsuario']]],
  ['settings_2edesigner_2ecs_1',['Settings.Designer.cs',['../_settings_8_designer_8cs.html',1,'']]]
];
