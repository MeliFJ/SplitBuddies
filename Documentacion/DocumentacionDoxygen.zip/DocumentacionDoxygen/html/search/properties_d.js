var searchData=
[
  ['usuarioid_0',['UsuarioId',['../class_modelo_1_1_relacion_usuario_gasto.html#ace976bc49584d92f1520b1e77b61c88d',1,'Modelo.RelacionUsuarioGasto.UsuarioId'],['../class_modelo_1_1_relacion_usuario_grupo.html#a160c7d5f648aefbca5d9a2272f723c01',1,'Modelo.RelacionUsuarioGrupo.UsuarioId']]]
];
