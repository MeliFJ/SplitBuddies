var searchData=
[
  ['nombre_0',['Nombre',['../class_modelo_1_1_grupo.html#adbec85075c91dbe9d81a005439ad8ac4',1,'Modelo.Grupo.Nombre'],['../class_modelo_1_1_usuario.html#a8b88f6d6db37bc2e3ec337dd1a2b0d78',1,'Modelo.Usuario.Nombre']]],
  ['nombregasto_1',['NombreGasto',['../class_modelo_1_1_gasto.html#aafdb0c057c30b4585b7ae036988f4d1d',1,'Modelo::Gasto']]],
  ['nombregrupo_2',['NombreGrupo',['../class_modelo_1_1_gasto_grupo_usuario.html#ac42bcda1f17bb44cd8f0ad32ccea0136',1,'Modelo::GastoGrupoUsuario']]],
  ['nombrelogo_3',['NombreLogo',['../class_modelo_1_1_grupo.html#a127a9c6cd70509e3b5590231c4c7ba7c',1,'Modelo::Grupo']]],
  ['nombreusuario_4',['NombreUsuario',['../class_modelo_1_1_gasto_grupo_usuario.html#a57c637f17b0a24e624de39b9f95b94c0',1,'Modelo::GastoGrupoUsuario']]]
];
