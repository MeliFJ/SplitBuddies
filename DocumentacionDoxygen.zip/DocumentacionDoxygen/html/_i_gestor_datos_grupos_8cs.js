var _i_gestor_datos_grupos_8cs =
[
    [ "GestorDatos.Interfaces.IGestorDatosGrupos", "interface_gestor_datos_1_1_interfaces_1_1_i_gestor_datos_grupos.html", "interface_gestor_datos_1_1_interfaces_1_1_i_gestor_datos_grupos" ]
];