var _i_grupo_controlador_8cs =
[
    [ "Controlador.Interfaces.IGrupoControlador", "interface_controlador_1_1_interfaces_1_1_i_grupo_controlador.html", "interface_controlador_1_1_interfaces_1_1_i_grupo_controlador" ]
];