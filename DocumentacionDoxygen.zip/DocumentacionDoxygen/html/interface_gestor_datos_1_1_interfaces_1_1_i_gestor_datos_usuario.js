var interface_gestor_datos_1_1_interfaces_1_1_i_gestor_datos_usuario =
[
    [ "BuscarUsuario", "interface_gestor_datos_1_1_interfaces_1_1_i_gestor_datos_usuario.html#aa33895e50e6ca7393e2027af5073b750", null ],
    [ "CargarUsuarioPorGrupos", "interface_gestor_datos_1_1_interfaces_1_1_i_gestor_datos_usuario.html#a652b13446f353c7a6274d0977710ee87", null ],
    [ "CargarUsuarios", "interface_gestor_datos_1_1_interfaces_1_1_i_gestor_datos_usuario.html#ab175fb3577c8da712f017a63355258fe", null ],
    [ "CargarUsuariosPorGastoId", "interface_gestor_datos_1_1_interfaces_1_1_i_gestor_datos_usuario.html#af26ebbe21bfcd3a486086d6f692a3195", null ],
    [ "GuardarUsuario", "interface_gestor_datos_1_1_interfaces_1_1_i_gestor_datos_usuario.html#a33f49380faf6e4d94255dc5c9bb4e3e3", null ]
];