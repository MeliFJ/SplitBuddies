var searchData=
[
  ['descripciongasto_0',['DescripcionGasto',['../class_modelo_1_1_gasto.html#a544825654adeac883eb2aac364313a73',1,'Modelo::Gasto']]],
  ['deuda_1',['Deuda',['../class_modelo_1_1_reporte.html#ad36f471addd1c30ba8c25c8d3bae4fb6',1,'Modelo::Reporte']]],
  ['disponible_2',['Disponible',['../class_modelo_1_1_reporte.html#af442ebf1a0317289460c32f14afedcb6',1,'Modelo::Reporte']]]
];
