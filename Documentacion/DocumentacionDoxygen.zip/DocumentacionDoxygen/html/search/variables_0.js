var searchData=
[
  ['btnagregargasto_0',['btnAgregarGasto',['../class_wf_vista_split_buddies_1_1_vista_1_1_form_gastos.html#ac2f0920840a4808867b48ebb92756f34',1,'WfVistaSplitBuddies::Vista::FormGastos']]]
];
