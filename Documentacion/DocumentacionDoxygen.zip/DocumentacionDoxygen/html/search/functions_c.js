var searchData=
[
  ['usuario_0',['Usuario',['../class_modelo_1_1_usuario.html#ac067c42becbdac2cb8205f3810c01d51',1,'Modelo::Usuario']]]
];
