var _i_gastos_controlador_8cs =
[
    [ "Controlador.Interfaces.IGastosControlador", "interface_controlador_1_1_interfaces_1_1_i_gastos_controlador.html", "interface_controlador_1_1_interfaces_1_1_i_gastos_controlador" ]
];