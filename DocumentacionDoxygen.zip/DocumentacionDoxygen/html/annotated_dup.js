var annotated_dup =
[
    [ "Controlador", "namespace_controlador.html", [
      [ "Interfaces", "namespace_controlador_1_1_interfaces.html", [
        [ "IGastosControlador", "interface_controlador_1_1_interfaces_1_1_i_gastos_controlador.html", "interface_controlador_1_1_interfaces_1_1_i_gastos_controlador" ],
        [ "IGrupoControlador", "interface_controlador_1_1_interfaces_1_1_i_grupo_controlador.html", "interface_controlador_1_1_interfaces_1_1_i_grupo_controlador" ],
        [ "IUsuarioControlador", "interface_controlador_1_1_interfaces_1_1_i_usuario_controlador.html", "interface_controlador_1_1_interfaces_1_1_i_usuario_controlador" ]
      ] ],
      [ "GastosControlador", "class_controlador_1_1_gastos_controlador.html", "class_controlador_1_1_gastos_controlador" ],
      [ "GrupoControlador", "class_controlador_1_1_grupo_controlador.html", null ],
      [ "LoginControlador", "class_controlador_1_1_login_controlador.html", "class_controlador_1_1_login_controlador" ],
      [ "UsuarioControlador", "class_controlador_1_1_usuario_controlador.html", "class_controlador_1_1_usuario_controlador" ]
    ] ],
    [ "GestorDatos", "namespace_gestor_datos.html", [
      [ "Interfaces", "namespace_gestor_datos_1_1_interfaces.html", [
        [ "IGestorDatosGastos", "interface_gestor_datos_1_1_interfaces_1_1_i_gestor_datos_gastos.html", "interface_gestor_datos_1_1_interfaces_1_1_i_gestor_datos_gastos" ],
        [ "IGestorDatosGrupos", "interface_gestor_datos_1_1_interfaces_1_1_i_gestor_datos_grupos.html", "interface_gestor_datos_1_1_interfaces_1_1_i_gestor_datos_grupos" ],
        [ "IGestorDatosUsuario", "interface_gestor_datos_1_1_interfaces_1_1_i_gestor_datos_usuario.html", "interface_gestor_datos_1_1_interfaces_1_1_i_gestor_datos_usuario" ]
      ] ],
      [ "GestorDatosBase", "class_gestor_datos_1_1_gestor_datos_base.html", null ],
      [ "GestorDatosGastos", "class_gestor_datos_1_1_gestor_datos_gastos.html", "class_gestor_datos_1_1_gestor_datos_gastos" ],
      [ "GestorDatosGrupos", "class_gestor_datos_1_1_gestor_datos_grupos.html", "class_gestor_datos_1_1_gestor_datos_grupos" ],
      [ "GestorDatosUsuario", "class_gestor_datos_1_1_gestor_datos_usuario.html", "class_gestor_datos_1_1_gestor_datos_usuario" ]
    ] ],
    [ "Modelo", "namespace_modelo.html", [
      [ "Gasto", "class_modelo_1_1_gasto.html", "class_modelo_1_1_gasto" ],
      [ "GastoGrupoUsuario", "class_modelo_1_1_gasto_grupo_usuario.html", "class_modelo_1_1_gasto_grupo_usuario" ],
      [ "Grupo", "class_modelo_1_1_grupo.html", "class_modelo_1_1_grupo" ],
      [ "RelacionGrupoGasto", "class_modelo_1_1_relacion_grupo_gasto.html", "class_modelo_1_1_relacion_grupo_gasto" ],
      [ "RelacionUsuarioGasto", "class_modelo_1_1_relacion_usuario_gasto.html", "class_modelo_1_1_relacion_usuario_gasto" ],
      [ "RelacionUsuarioGrupo", "class_modelo_1_1_relacion_usuario_grupo.html", "class_modelo_1_1_relacion_usuario_grupo" ],
      [ "Reporte", "class_modelo_1_1_reporte.html", "class_modelo_1_1_reporte" ],
      [ "Usuario", "class_modelo_1_1_usuario.html", "class_modelo_1_1_usuario" ]
    ] ],
    [ "WfVistaSplitBuddies", "namespace_wf_vista_split_buddies.html", [
      [ "Vista", "namespace_wf_vista_split_buddies_1_1_vista.html", [
        [ "FormGastos", "class_wf_vista_split_buddies_1_1_vista_1_1_form_gastos.html", "class_wf_vista_split_buddies_1_1_vista_1_1_form_gastos" ],
        [ "FormGrupo", "class_wf_vista_split_buddies_1_1_vista_1_1_form_grupo.html", "class_wf_vista_split_buddies_1_1_vista_1_1_form_grupo" ],
        [ "MostrarGrupos", "class_wf_vista_split_buddies_1_1_vista_1_1_mostrar_grupos.html", "class_wf_vista_split_buddies_1_1_vista_1_1_mostrar_grupos" ],
        [ "RegistrarUsuario", "class_wf_vista_split_buddies_1_1_vista_1_1_registrar_usuario.html", "class_wf_vista_split_buddies_1_1_vista_1_1_registrar_usuario" ]
      ] ],
      [ "Form1", "class_wf_vista_split_buddies_1_1_form1.html", "class_wf_vista_split_buddies_1_1_form1" ],
      [ "FormReporte", "class_wf_vista_split_buddies_1_1_form_reporte.html", "class_wf_vista_split_buddies_1_1_form_reporte" ],
      [ "FormResumenGastosPorUsuario", "class_wf_vista_split_buddies_1_1_form_resumen_gastos_por_usuario.html", "class_wf_vista_split_buddies_1_1_form_resumen_gastos_por_usuario" ]
    ] ]
];