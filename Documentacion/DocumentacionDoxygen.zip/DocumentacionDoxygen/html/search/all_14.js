var searchData=
[
  ['wfvistasplitbuddies_0',['WfVistaSplitBuddies',['../namespace_wf_vista_split_buddies.html',1,'']]],
  ['wfvistasplitbuddies_3a_3aproperties_1',['Properties',['../namespace_wf_vista_split_buddies_1_1_properties.html',1,'WfVistaSplitBuddies']]],
  ['wfvistasplitbuddies_3a_3avista_2',['Vista',['../namespace_wf_vista_split_buddies_1_1_vista.html',1,'WfVistaSplitBuddies']]]
];
