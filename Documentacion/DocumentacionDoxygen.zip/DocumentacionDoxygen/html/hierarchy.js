var hierarchy =
[
    [ "Form", null, [
      [ "WfVistaSplitBuddies.Form1", "class_wf_vista_split_buddies_1_1_form1.html", null ],
      [ "WfVistaSplitBuddies.FormReporte", "class_wf_vista_split_buddies_1_1_form_reporte.html", null ],
      [ "WfVistaSplitBuddies.FormResumenGastosPorUsuario", "class_wf_vista_split_buddies_1_1_form_resumen_gastos_por_usuario.html", null ],
      [ "WfVistaSplitBuddies.Vista.FormGastos", "class_wf_vista_split_buddies_1_1_vista_1_1_form_gastos.html", null ],
      [ "WfVistaSplitBuddies.Vista.FormGrupo", "class_wf_vista_split_buddies_1_1_vista_1_1_form_grupo.html", null ],
      [ "WfVistaSplitBuddies.Vista.MostrarGrupos", "class_wf_vista_split_buddies_1_1_vista_1_1_mostrar_grupos.html", null ],
      [ "WfVistaSplitBuddies.Vista.RegistrarUsuario", "class_wf_vista_split_buddies_1_1_vista_1_1_registrar_usuario.html", null ]
    ] ],
    [ "Modelo.Gasto", "class_modelo_1_1_gasto.html", null ],
    [ "Modelo.GastoGrupoUsuario", "class_modelo_1_1_gasto_grupo_usuario.html", null ],
    [ "GestorDatos.GestorDatosBase", "class_gestor_datos_1_1_gestor_datos_base.html", [
      [ "GestorDatos.GestorDatosGastos", "class_gestor_datos_1_1_gestor_datos_gastos.html", null ],
      [ "GestorDatos.GestorDatosGrupos", "class_gestor_datos_1_1_gestor_datos_grupos.html", null ],
      [ "GestorDatos.GestorDatosUsuario", "class_gestor_datos_1_1_gestor_datos_usuario.html", null ]
    ] ],
    [ "Modelo.Grupo", "class_modelo_1_1_grupo.html", null ],
    [ "Controlador.Interfaces.IGastosControlador", "interface_controlador_1_1_interfaces_1_1_i_gastos_controlador.html", [
      [ "Controlador.GastosControlador", "class_controlador_1_1_gastos_controlador.html", null ]
    ] ],
    [ "GestorDatos.Interfaces.IGestorDatosGastos", "interface_gestor_datos_1_1_interfaces_1_1_i_gestor_datos_gastos.html", [
      [ "GestorDatos.GestorDatosGastos", "class_gestor_datos_1_1_gestor_datos_gastos.html", null ]
    ] ],
    [ "GestorDatos.Interfaces.IGestorDatosGrupos", "interface_gestor_datos_1_1_interfaces_1_1_i_gestor_datos_grupos.html", [
      [ "GestorDatos.GestorDatosGrupos", "class_gestor_datos_1_1_gestor_datos_grupos.html", null ]
    ] ],
    [ "GestorDatos.Interfaces.IGestorDatosUsuario", "interface_gestor_datos_1_1_interfaces_1_1_i_gestor_datos_usuario.html", [
      [ "GestorDatos.GestorDatosUsuario", "class_gestor_datos_1_1_gestor_datos_usuario.html", null ]
    ] ],
    [ "Controlador.Interfaces.IGrupoControlador", "interface_controlador_1_1_interfaces_1_1_i_grupo_controlador.html", [
      [ "Controlador.GrupoControlador", "class_controlador_1_1_grupo_controlador.html", null ]
    ] ],
    [ "Controlador.Interfaces.IUsuarioControlador", "interface_controlador_1_1_interfaces_1_1_i_usuario_controlador.html", [
      [ "Controlador.UsuarioControlador", "class_controlador_1_1_usuario_controlador.html", null ]
    ] ],
    [ "Controlador.LoginControlador", "class_controlador_1_1_login_controlador.html", null ],
    [ "Modelo.RelacionGrupoGasto", "class_modelo_1_1_relacion_grupo_gasto.html", null ],
    [ "Modelo.RelacionUsuarioGasto", "class_modelo_1_1_relacion_usuario_gasto.html", null ],
    [ "Modelo.RelacionUsuarioGrupo", "class_modelo_1_1_relacion_usuario_grupo.html", null ],
    [ "Modelo.Reporte", "class_modelo_1_1_reporte.html", null ],
    [ "Modelo.Usuario", "class_modelo_1_1_usuario.html", null ]
];