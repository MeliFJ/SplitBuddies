var dir_a89219db6e4e0320a2c10b0dadad7d46 =
[
    [ "IGestorDatosGastos.cs", "_i_gestor_datos_gastos_8cs.html", "_i_gestor_datos_gastos_8cs" ],
    [ "IGestorDatosGrupos.cs", "_i_gestor_datos_grupos_8cs.html", "_i_gestor_datos_grupos_8cs" ],
    [ "IGestorDatosUsuario.cs", "_i_gestor_datos_usuario_8cs.html", "_i_gestor_datos_usuario_8cs" ]
];