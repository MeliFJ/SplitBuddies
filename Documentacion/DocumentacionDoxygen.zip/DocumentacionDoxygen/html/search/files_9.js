var searchData=
[
  ['settings_2edesigner_2ecs_0',['Settings.Designer.cs',['../_settings_8_designer_8cs.html',1,'']]]
];
