var _gastos_controlador_8cs =
[
    [ "Controlador.GastosControlador", "class_controlador_1_1_gastos_controlador.html", "class_controlador_1_1_gastos_controlador" ]
];