var interface_controlador_1_1_interfaces_1_1_i_gastos_controlador =
[
    [ "ActualizarGasto", "interface_controlador_1_1_interfaces_1_1_i_gastos_controlador.html#a5f9198677216d0fea3df0f13a731bb96", null ],
    [ "CargarGastoPorGrupo", "interface_controlador_1_1_interfaces_1_1_i_gastos_controlador.html#aa50dd519774514514f3ae572834ae1a2", null ],
    [ "CargarGastoPorUsuarioEnGrupo", "interface_controlador_1_1_interfaces_1_1_i_gastos_controlador.html#abd8602e9e5c65e2e77f11cbfc275d74e", null ],
    [ "ConsultarGastosPorGrupoyUsuario", "interface_controlador_1_1_interfaces_1_1_i_gastos_controlador.html#a6678df637505e031178198d3d48f0215", null ],
    [ "ConsultarGastosPorUsuario", "interface_controlador_1_1_interfaces_1_1_i_gastos_controlador.html#a767ec37af4d596b61fe7577ed554bf13", null ],
    [ "EliminarGasto", "interface_controlador_1_1_interfaces_1_1_i_gastos_controlador.html#af0738c8e688eb9d55d0ca0cdc1768093", null ],
    [ "GenerarReportePorAnno", "interface_controlador_1_1_interfaces_1_1_i_gastos_controlador.html#a54011fdc69444e1f68b2a123c6449d1a", null ],
    [ "GenerarReportePorFechas", "interface_controlador_1_1_interfaces_1_1_i_gastos_controlador.html#a66f00093a7de7eeb51635c5991959ba1", null ],
    [ "GenerarReportePorMes", "interface_controlador_1_1_interfaces_1_1_i_gastos_controlador.html#a37ebf7b5c66f5ec712b3ea2855c2123c", null ],
    [ "guardarGasto", "interface_controlador_1_1_interfaces_1_1_i_gastos_controlador.html#a4bd75d8f03a79d8c62d898bb6b719107", null ]
];