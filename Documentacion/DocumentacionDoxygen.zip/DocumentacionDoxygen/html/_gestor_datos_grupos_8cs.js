var _gestor_datos_grupos_8cs =
[
    [ "GestorDatos.GestorDatosGrupos", "class_gestor_datos_1_1_gestor_datos_grupos.html", "class_gestor_datos_1_1_gestor_datos_grupos" ]
];