var class_modelo_1_1_gasto =
[
    [ "Gasto", "class_modelo_1_1_gasto.html#af8e830d14730b9ca66e6d1937b2141b6", null ],
    [ "Gasto", "class_modelo_1_1_gasto.html#a2f34f73654b801c130df82ee630c3ecc", null ],
    [ "ActualizarDesde", "class_modelo_1_1_gasto.html#a250badc8379104878eddfeeb467fd7dc", null ],
    [ "ToString", "class_modelo_1_1_gasto.html#ab6d2be2d139ff7a7cf0ebf8ec3f9c153", null ],
    [ "DescripcionGasto", "class_modelo_1_1_gasto.html#a544825654adeac883eb2aac364313a73", null ],
    [ "EnlaceGasto", "class_modelo_1_1_gasto.html#ace8d6dd90be4d18d2dce1ac4b4f432ed", null ],
    [ "FechaSeleccionada", "class_modelo_1_1_gasto.html#a5bab196086fda2b9753ec3ebb7977bf4", null ],
    [ "Id", "class_modelo_1_1_gasto.html#aee41a355d146202d11bf52e8ca44eda6", null ],
    [ "MontoGasto", "class_modelo_1_1_gasto.html#ac20012c5dbd78a03c8f9cdcdb7a49d25", null ],
    [ "NombreGasto", "class_modelo_1_1_gasto.html#aafdb0c057c30b4585b7ae036988f4d1d", null ],
    [ "QuienPagoId", "class_modelo_1_1_gasto.html#aee60b0619cbcb25344dce6477a4c8796", null ]
];