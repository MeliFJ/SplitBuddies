var _relacion_usuario_gasto_8cs =
[
    [ "Modelo.RelacionUsuarioGasto", "class_modelo_1_1_relacion_usuario_gasto.html", "class_modelo_1_1_relacion_usuario_gasto" ]
];