var namespace_wf_vista_split_buddies =
[
    [ "Properties", "namespace_wf_vista_split_buddies_1_1_properties.html", null ],
    [ "Vista", "namespace_wf_vista_split_buddies_1_1_vista.html", "namespace_wf_vista_split_buddies_1_1_vista" ],
    [ "Form1", "class_wf_vista_split_buddies_1_1_form1.html", "class_wf_vista_split_buddies_1_1_form1" ],
    [ "FormReporte", "class_wf_vista_split_buddies_1_1_form_reporte.html", "class_wf_vista_split_buddies_1_1_form_reporte" ],
    [ "FormResumenGastosPorUsuario", "class_wf_vista_split_buddies_1_1_form_resumen_gastos_por_usuario.html", "class_wf_vista_split_buddies_1_1_form_resumen_gastos_por_usuario" ]
];