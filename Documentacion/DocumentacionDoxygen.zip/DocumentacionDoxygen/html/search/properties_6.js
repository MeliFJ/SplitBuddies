var searchData=
[
  ['id_0',['Id',['../class_modelo_1_1_gasto.html#aee41a355d146202d11bf52e8ca44eda6',1,'Modelo.Gasto.Id'],['../class_modelo_1_1_grupo.html#a54af14e2463b7afab0a782b2671b0eed',1,'Modelo.Grupo.Id']]],
  ['identificacion_1',['Identificacion',['../class_modelo_1_1_usuario.html#a235419bd65ed45bc7906ba5ba106f7cb',1,'Modelo::Usuario']]]
];
