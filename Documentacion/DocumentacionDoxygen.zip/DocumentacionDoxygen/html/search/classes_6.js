var searchData=
[
  ['usuario_0',['Usuario',['../class_modelo_1_1_usuario.html',1,'Modelo']]],
  ['usuariocontrolador_1',['UsuarioControlador',['../class_controlador_1_1_usuario_controlador.html',1,'Controlador']]]
];
