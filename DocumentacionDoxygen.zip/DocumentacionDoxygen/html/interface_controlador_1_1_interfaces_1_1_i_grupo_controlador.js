var interface_controlador_1_1_interfaces_1_1_i_grupo_controlador =
[
    [ "CargarGruposPorUsuario", "interface_controlador_1_1_interfaces_1_1_i_grupo_controlador.html#a4e977211bfddd8ebb73daa73189a3997", null ],
    [ "cargarPosiblesIntegrantes", "interface_controlador_1_1_interfaces_1_1_i_grupo_controlador.html#a914c3cc64d3ac6c54c697e592f597ace", null ],
    [ "CargarUsuarioPorGrupos", "interface_controlador_1_1_interfaces_1_1_i_grupo_controlador.html#a5cea40c5c74987c48fa6a907c6a00f46", null ],
    [ "guardaGrupo", "interface_controlador_1_1_interfaces_1_1_i_grupo_controlador.html#ab9f6ee2891e453e26882e5c1719f72ae", null ],
    [ "guardaLogo", "interface_controlador_1_1_interfaces_1_1_i_grupo_controlador.html#a79f69ef0faee57778d19b2f9ea56c9a2", null ]
];