var class_modelo_1_1_relacion_usuario_gasto =
[
    [ "RelacionUsuarioGasto", "class_modelo_1_1_relacion_usuario_gasto.html#a53e359f38dc7951a9866559bcca6b3c6", null ],
    [ "RelacionUsuarioGasto", "class_modelo_1_1_relacion_usuario_gasto.html#ac61f82a82ecaaf3972bc6c713209db3c", null ],
    [ "GastoId", "class_modelo_1_1_relacion_usuario_gasto.html#af5a6df6e93b024477e5daff3469fc62d", null ],
    [ "UsuarioId", "class_modelo_1_1_relacion_usuario_gasto.html#ace976bc49584d92f1520b1e77b61c88d", null ]
];