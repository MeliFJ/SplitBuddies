var searchData=
[
  ['validarlogin_0',['ValidarLogin',['../class_controlador_1_1_login_controlador.html#a56aaf9a6279b97ebc1870df06f728df9',1,'Controlador::LoginControlador']]]
];
