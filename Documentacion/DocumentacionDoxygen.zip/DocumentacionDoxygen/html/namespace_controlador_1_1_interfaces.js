var namespace_controlador_1_1_interfaces =
[
    [ "IGastosControlador", "interface_controlador_1_1_interfaces_1_1_i_gastos_controlador.html", "interface_controlador_1_1_interfaces_1_1_i_gastos_controlador" ],
    [ "IGrupoControlador", "interface_controlador_1_1_interfaces_1_1_i_grupo_controlador.html", "interface_controlador_1_1_interfaces_1_1_i_grupo_controlador" ],
    [ "IUsuarioControlador", "interface_controlador_1_1_interfaces_1_1_i_usuario_controlador.html", "interface_controlador_1_1_interfaces_1_1_i_usuario_controlador" ]
];