var _gestor_datos_usuario_8cs =
[
    [ "GestorDatos.GestorDatosUsuario", "class_gestor_datos_1_1_gestor_datos_usuario.html", "class_gestor_datos_1_1_gestor_datos_usuario" ]
];