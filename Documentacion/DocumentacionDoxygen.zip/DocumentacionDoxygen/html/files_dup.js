var files_dup =
[
    [ "SplitBuddies", "dir_c7020277b8cc86746ba9555276f49f56.html", "dir_c7020277b8cc86746ba9555276f49f56" ]
];