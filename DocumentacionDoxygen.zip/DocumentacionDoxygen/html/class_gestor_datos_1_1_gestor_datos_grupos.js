var class_gestor_datos_1_1_gestor_datos_grupos =
[
    [ "CargarGrupos", "class_gestor_datos_1_1_gestor_datos_grupos.html#aafdc5d6eedf26ecfce5a7ac070f7d978", null ],
    [ "CargarGruposPorUsuario", "class_gestor_datos_1_1_gestor_datos_grupos.html#a942d1cdaf17052d1562e5e8c7504a35b", null ],
    [ "CargarUsuarioGrupos", "class_gestor_datos_1_1_gestor_datos_grupos.html#a2e3a24d4ba0dc3b36669755c9975dba4", null ],
    [ "EsNombreGrupoUnico", "class_gestor_datos_1_1_gestor_datos_grupos.html#a8a20711d776104a48be3f7c30bdcebb8", null ],
    [ "GuardarGrupos", "class_gestor_datos_1_1_gestor_datos_grupos.html#aaa84c4e0942e74af56a40293883af885", null ],
    [ "GuardarUsuarioGrupo", "class_gestor_datos_1_1_gestor_datos_grupos.html#ac6bc8598f3d0d15a396ed0b42d6fa3f3", null ]
];