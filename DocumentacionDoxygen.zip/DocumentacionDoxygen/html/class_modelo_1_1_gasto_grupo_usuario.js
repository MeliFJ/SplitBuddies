var class_modelo_1_1_gasto_grupo_usuario =
[
    [ "CantidadIntegrantes", "class_modelo_1_1_gasto_grupo_usuario.html#a9c7ebe7581da38b51c8838391ddb9da4", null ],
    [ "Gastos", "class_modelo_1_1_gasto_grupo_usuario.html#a7ff7126a892a2e94d448ddea26d5e1af", null ],
    [ "NombreGrupo", "class_modelo_1_1_gasto_grupo_usuario.html#ac42bcda1f17bb44cd8f0ad32ccea0136", null ],
    [ "NombreUsuario", "class_modelo_1_1_gasto_grupo_usuario.html#a57c637f17b0a24e624de39b9f95b94c0", null ],
    [ "SaldoUsuario", "class_modelo_1_1_gasto_grupo_usuario.html#af8a86e1b9d92a8571817f302eea67b0f", null ],
    [ "TotalGastosGrupo", "class_modelo_1_1_gasto_grupo_usuario.html#a673a8cbccd21c57643888c59d09e590a", null ],
    [ "TotalGastosPorIntegrante", "class_modelo_1_1_gasto_grupo_usuario.html#a6fcefc6ef0ac0032028029349751575d", null ],
    [ "TotalGastosPorUsuario", "class_modelo_1_1_gasto_grupo_usuario.html#ada1ab65f06565bd54c8a35bb743e98d8", null ]
];