var searchData=
[
  ['montogasto_0',['MontoGasto',['../class_modelo_1_1_gasto.html#ac20012c5dbd78a03c8f9cdcdb7a49d25',1,'Modelo::Gasto']]]
];
