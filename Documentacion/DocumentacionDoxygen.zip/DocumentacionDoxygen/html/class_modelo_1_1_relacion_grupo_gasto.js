var class_modelo_1_1_relacion_grupo_gasto =
[
    [ "RelacionGrupoGasto", "class_modelo_1_1_relacion_grupo_gasto.html#a4f7ad0c51d9b6924144f3ecd3a707185", null ],
    [ "RelacionGrupoGasto", "class_modelo_1_1_relacion_grupo_gasto.html#ae9ea8b145049fc5bdff6de8e5be742d5", null ],
    [ "GastoId", "class_modelo_1_1_relacion_grupo_gasto.html#a797a044a1b0b8e3db91a0cab5f0cd93f", null ],
    [ "GrupoId", "class_modelo_1_1_relacion_grupo_gasto.html#ac2160566b87c589fb704eed220662a15", null ]
];