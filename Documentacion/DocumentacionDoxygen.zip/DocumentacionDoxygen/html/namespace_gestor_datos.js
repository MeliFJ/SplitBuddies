var namespace_gestor_datos =
[
    [ "Interfaces", "namespace_gestor_datos_1_1_interfaces.html", "namespace_gestor_datos_1_1_interfaces" ],
    [ "GestorDatosBase", "class_gestor_datos_1_1_gestor_datos_base.html", null ],
    [ "GestorDatosGastos", "class_gestor_datos_1_1_gestor_datos_gastos.html", "class_gestor_datos_1_1_gestor_datos_gastos" ],
    [ "GestorDatosGrupos", "class_gestor_datos_1_1_gestor_datos_grupos.html", "class_gestor_datos_1_1_gestor_datos_grupos" ],
    [ "GestorDatosUsuario", "class_gestor_datos_1_1_gestor_datos_usuario.html", "class_gestor_datos_1_1_gestor_datos_usuario" ]
];