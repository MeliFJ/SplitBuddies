var searchData=
[
  ['datachanged_0',['DataChanged',['../class_wf_vista_split_buddies_1_1_vista_1_1_form_gastos.html#ae127d17aecf73958570e8a47dbe98fb2',1,'WfVistaSplitBuddies::Vista::FormGastos']]]
];
