var searchData=
[
  ['tostring_0',['ToString',['../class_modelo_1_1_gasto.html#ab6d2be2d139ff7a7cf0ebf8ec3f9c153',1,'Modelo.Gasto.ToString()'],['../class_modelo_1_1_usuario.html#a143a3696fe3effdef8dbcbe2fbf73e13',1,'Modelo.Usuario.ToString()']]]
];
