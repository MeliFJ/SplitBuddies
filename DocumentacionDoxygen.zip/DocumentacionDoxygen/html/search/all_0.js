var searchData=
[
  ['_2enetframework_2cversion_3dv4_2e8_2eassemblyattributes_2ecs_0',['.NETFramework,Version=v4.8.AssemblyAttributes.cs',['../_8_n_e_t_framework_00_version_0av4_88_8_assembly_attributes_8cs.html',1,'']]]
];
