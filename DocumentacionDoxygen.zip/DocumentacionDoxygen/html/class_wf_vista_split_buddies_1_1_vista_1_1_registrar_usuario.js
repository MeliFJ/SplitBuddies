var class_wf_vista_split_buddies_1_1_vista_1_1_registrar_usuario =
[
    [ "RegistrarUsuario", "class_wf_vista_split_buddies_1_1_vista_1_1_registrar_usuario.html#a07674fe4f315760dccb909028fe59d78", null ],
    [ "Dispose", "class_wf_vista_split_buddies_1_1_vista_1_1_registrar_usuario.html#adbbe9ae5f61f8bbcee124a9636d33cf1", null ]
];