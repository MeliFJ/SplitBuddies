var searchData=
[
  ['assemblyinfo_2ecs_0',['AssemblyInfo.cs',['../_controlador_2_properties_2_assembly_info_8cs.html',1,'(Global Namespace)'],['../_wf_vista_split_buddies_2_properties_2_assembly_info_8cs.html',1,'(Global Namespace)']]]
];
