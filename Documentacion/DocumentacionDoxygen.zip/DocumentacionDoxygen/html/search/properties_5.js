var searchData=
[
  ['gastoid_0',['GastoId',['../class_modelo_1_1_relacion_grupo_gasto.html#a797a044a1b0b8e3db91a0cab5f0cd93f',1,'Modelo.RelacionGrupoGasto.GastoId'],['../class_modelo_1_1_relacion_usuario_gasto.html#af5a6df6e93b024477e5daff3469fc62d',1,'Modelo.RelacionUsuarioGasto.GastoId']]],
  ['gastos_1',['Gastos',['../class_modelo_1_1_gasto_grupo_usuario.html#a7ff7126a892a2e94d448ddea26d5e1af',1,'Modelo::GastoGrupoUsuario']]],
  ['gastototal_2',['GastoTotal',['../class_modelo_1_1_reporte.html#a5dbd25aa70cceef313280db206ff3ffb',1,'Modelo::Reporte']]],
  ['grupoid_3',['GrupoId',['../class_modelo_1_1_relacion_grupo_gasto.html#ac2160566b87c589fb704eed220662a15',1,'Modelo.RelacionGrupoGasto.GrupoId'],['../class_modelo_1_1_relacion_usuario_grupo.html#a0c83057df59c5c1b178dd1618268dfdb',1,'Modelo.RelacionUsuarioGrupo.GrupoId']]]
];
