var searchData=
[
  ['btnagregargasto_0',['btnAgregarGasto',['../class_wf_vista_split_buddies_1_1_vista_1_1_form_gastos.html#ac2f0920840a4808867b48ebb92756f34',1,'WfVistaSplitBuddies::Vista::FormGastos']]],
  ['buscarusuario_1',['BuscarUsuario',['../interface_controlador_1_1_interfaces_1_1_i_usuario_controlador.html#a7dff73ef5c68b16636ecefa2b66c64a9',1,'Controlador.Interfaces.IUsuarioControlador.BuscarUsuario()'],['../class_controlador_1_1_usuario_controlador.html#ace8673552c52c864172c6ee1be342c4a',1,'Controlador.UsuarioControlador.BuscarUsuario()'],['../class_gestor_datos_1_1_gestor_datos_usuario.html#ada20f9cb00e5ce0a97fcb3df4b9dced7',1,'GestorDatos.GestorDatosUsuario.BuscarUsuario()'],['../interface_gestor_datos_1_1_interfaces_1_1_i_gestor_datos_usuario.html#aa33895e50e6ca7393e2027af5073b750',1,'GestorDatos.Interfaces.IGestorDatosUsuario.BuscarUsuario()']]]
];
