var searchData=
[
  ['obtenerreporteporusuario_0',['ObtenerReportePorUsuario',['../class_gestor_datos_1_1_gestor_datos_gastos.html#af85052c2032c84e7f6b0ca549a89edbb',1,'GestorDatos.GestorDatosGastos.ObtenerReportePorUsuario()'],['../interface_gestor_datos_1_1_interfaces_1_1_i_gestor_datos_gastos.html#a22d5a19be371ada40694dafdac7fb543',1,'GestorDatos.Interfaces.IGestorDatosGastos.ObtenerReportePorUsuario()']]]
];
