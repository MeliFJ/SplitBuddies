var _form_gastos_8_designer_8cs =
[
    [ "WfVistaSplitBuddies.Vista.FormGastos", "class_wf_vista_split_buddies_1_1_vista_1_1_form_gastos.html", "class_wf_vista_split_buddies_1_1_vista_1_1_form_gastos" ]
];