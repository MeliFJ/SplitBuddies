var namespace_wf_vista_split_buddies_1_1_vista =
[
    [ "FormGastos", "class_wf_vista_split_buddies_1_1_vista_1_1_form_gastos.html", "class_wf_vista_split_buddies_1_1_vista_1_1_form_gastos" ],
    [ "FormGrupo", "class_wf_vista_split_buddies_1_1_vista_1_1_form_grupo.html", "class_wf_vista_split_buddies_1_1_vista_1_1_form_grupo" ],
    [ "MostrarGrupos", "class_wf_vista_split_buddies_1_1_vista_1_1_mostrar_grupos.html", "class_wf_vista_split_buddies_1_1_vista_1_1_mostrar_grupos" ],
    [ "RegistrarUsuario", "class_wf_vista_split_buddies_1_1_vista_1_1_registrar_usuario.html", "class_wf_vista_split_buddies_1_1_vista_1_1_registrar_usuario" ]
];