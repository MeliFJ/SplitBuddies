var _form_resumen_gastos_por_usuario_8cs =
[
    [ "WfVistaSplitBuddies.FormResumenGastosPorUsuario", "class_wf_vista_split_buddies_1_1_form_resumen_gastos_por_usuario.html", "class_wf_vista_split_buddies_1_1_form_resumen_gastos_por_usuario" ]
];