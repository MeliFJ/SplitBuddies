var namespace_modelo =
[
    [ "Gasto", "class_modelo_1_1_gasto.html", "class_modelo_1_1_gasto" ],
    [ "GastoGrupoUsuario", "class_modelo_1_1_gasto_grupo_usuario.html", "class_modelo_1_1_gasto_grupo_usuario" ],
    [ "Grupo", "class_modelo_1_1_grupo.html", "class_modelo_1_1_grupo" ],
    [ "RelacionGrupoGasto", "class_modelo_1_1_relacion_grupo_gasto.html", "class_modelo_1_1_relacion_grupo_gasto" ],
    [ "RelacionUsuarioGasto", "class_modelo_1_1_relacion_usuario_gasto.html", "class_modelo_1_1_relacion_usuario_gasto" ],
    [ "RelacionUsuarioGrupo", "class_modelo_1_1_relacion_usuario_grupo.html", "class_modelo_1_1_relacion_usuario_grupo" ],
    [ "Reporte", "class_modelo_1_1_reporte.html", "class_modelo_1_1_reporte" ],
    [ "Usuario", "class_modelo_1_1_usuario.html", "class_modelo_1_1_usuario" ]
];