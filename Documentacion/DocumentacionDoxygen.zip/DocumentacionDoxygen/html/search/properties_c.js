var searchData=
[
  ['totalgastosgrupo_0',['TotalGastosGrupo',['../class_modelo_1_1_gasto_grupo_usuario.html#a673a8cbccd21c57643888c59d09e590a',1,'Modelo::GastoGrupoUsuario']]],
  ['totalgastosporintegrante_1',['TotalGastosPorIntegrante',['../class_modelo_1_1_gasto_grupo_usuario.html#a6fcefc6ef0ac0032028029349751575d',1,'Modelo::GastoGrupoUsuario']]],
  ['totalgastosporusuario_2',['TotalGastosPorUsuario',['../class_modelo_1_1_gasto_grupo_usuario.html#ada1ab65f06565bd54c8a35bb743e98d8',1,'Modelo::GastoGrupoUsuario']]]
];
