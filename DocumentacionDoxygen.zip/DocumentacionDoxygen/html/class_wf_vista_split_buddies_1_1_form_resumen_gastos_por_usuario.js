var class_wf_vista_split_buddies_1_1_form_resumen_gastos_por_usuario =
[
    [ "FormResumenGastosPorUsuario", "class_wf_vista_split_buddies_1_1_form_resumen_gastos_por_usuario.html#ac2fb9f52cede5ec76bf6a6e3151e17cb", null ],
    [ "Dispose", "class_wf_vista_split_buddies_1_1_form_resumen_gastos_por_usuario.html#a29a8cd9cc8ed044dac9a60f77f1a0cc0", null ]
];