var class_wf_vista_split_buddies_1_1_form1 =
[
    [ "Form1", "class_wf_vista_split_buddies_1_1_form1.html#ac970d7d28f0f80c9e265609b5b0cd4d0", null ],
    [ "Dispose", "class_wf_vista_split_buddies_1_1_form1.html#af80cad5736327ec9596c2ca597be0dbf", null ]
];