var namespace_controlador =
[
    [ "Interfaces", "namespace_controlador_1_1_interfaces.html", "namespace_controlador_1_1_interfaces" ],
    [ "GastosControlador", "class_controlador_1_1_gastos_controlador.html", "class_controlador_1_1_gastos_controlador" ],
    [ "GrupoControlador", "class_controlador_1_1_grupo_controlador.html", null ],
    [ "LoginControlador", "class_controlador_1_1_login_controlador.html", "class_controlador_1_1_login_controlador" ],
    [ "UsuarioControlador", "class_controlador_1_1_usuario_controlador.html", "class_controlador_1_1_usuario_controlador" ]
];