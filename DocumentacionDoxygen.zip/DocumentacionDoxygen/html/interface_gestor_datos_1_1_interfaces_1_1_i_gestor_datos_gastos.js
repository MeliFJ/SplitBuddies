var interface_gestor_datos_1_1_interfaces_1_1_i_gestor_datos_gastos =
[
    [ "ActualizarGasto", "interface_gestor_datos_1_1_interfaces_1_1_i_gestor_datos_gastos.html#a79eba9e9ca4a734f19d16bf97e2b4367", null ],
    [ "CargarGastos", "interface_gestor_datos_1_1_interfaces_1_1_i_gestor_datos_gastos.html#a173a71820d26b356acc8e4bf992e0b6d", null ],
    [ "CargarGastosXGrupo", "interface_gestor_datos_1_1_interfaces_1_1_i_gestor_datos_gastos.html#aca7440e39ad287ef666e2e7d3c355596", null ],
    [ "ConsultarGastosPorGrupoyUsuario", "interface_gestor_datos_1_1_interfaces_1_1_i_gestor_datos_gastos.html#aa87918a843d9217094bfbc3f3a67bd99", null ],
    [ "ConsultarGastosPorUsuario", "interface_gestor_datos_1_1_interfaces_1_1_i_gestor_datos_gastos.html#a2d60e2cba957dec3810d940ab9dde442", null ],
    [ "EliminarGasto", "interface_gestor_datos_1_1_interfaces_1_1_i_gestor_datos_gastos.html#a67942cb45791bf68c095c0984440ccef", null ],
    [ "GuardarGasto", "interface_gestor_datos_1_1_interfaces_1_1_i_gestor_datos_gastos.html#a167dee38b0bcd8aff2fd599bf340375b", null ],
    [ "guardarGrupoGasto", "interface_gestor_datos_1_1_interfaces_1_1_i_gestor_datos_gastos.html#ad0c2818e55e392640c7965a7f03df9fc", null ],
    [ "ObtenerReportePorUsuario", "interface_gestor_datos_1_1_interfaces_1_1_i_gestor_datos_gastos.html#a22d5a19be371ada40694dafdac7fb543", null ],
    [ "List< RelacionGrupoGasto >", "interface_gestor_datos_1_1_interfaces_1_1_i_gestor_datos_gastos.html#a9566853ce213380eb04b4d582810faa2", null ],
    [ "List< RelacionUsuarioGasto >", "interface_gestor_datos_1_1_interfaces_1_1_i_gestor_datos_gastos.html#ae0295ae328efceb3fbc080fc4868e9c4", null ]
];