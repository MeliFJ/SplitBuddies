var dir_9f2f487a381e9fda5fff2b0e2975b840 =
[
    [ "AssemblyInfo.cs", "_assembly_info_8cs.html", null ],
    [ "Resources.Designer.cs", "_resources_8_designer_8cs.html", null ],
    [ "Settings.Designer.cs", "_settings_8_designer_8cs.html", null ]
];