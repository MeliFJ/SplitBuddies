var searchData=
[
  ['enlacegasto_0',['EnlaceGasto',['../class_modelo_1_1_gasto.html#ace8d6dd90be4d18d2dce1ac4b4f432ed',1,'Modelo::Gasto']]]
];
