var class_wf_vista_split_buddies_1_1_vista_1_1_form_gastos =
[
    [ "FormGastos", "class_wf_vista_split_buddies_1_1_vista_1_1_form_gastos.html#a0324949f4e1b7d19eaf257d0adeae66f", null ],
    [ "FormGastos", "class_wf_vista_split_buddies_1_1_vista_1_1_form_gastos.html#ad04900c69db8b7db1f825f3bcffb09ba", null ],
    [ "Dispose", "class_wf_vista_split_buddies_1_1_vista_1_1_form_gastos.html#a421af206b8d11faa2dc78aaaa8c16bb0", null ],
    [ "btnAgregarGasto", "class_wf_vista_split_buddies_1_1_vista_1_1_form_gastos.html#ac2f0920840a4808867b48ebb92756f34", null ],
    [ "DataChanged", "class_wf_vista_split_buddies_1_1_vista_1_1_form_gastos.html#ae127d17aecf73958570e8a47dbe98fb2", null ]
];