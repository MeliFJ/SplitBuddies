var searchData=
[
  ['gestordatos_0',['GestorDatos',['../namespace_gestor_datos.html',1,'']]],
  ['gestordatos_3a_3ainterfaces_1',['Interfaces',['../namespace_gestor_datos_1_1_interfaces.html',1,'GestorDatos']]]
];
