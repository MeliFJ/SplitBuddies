var searchData=
[
  ['cantidadintegrantes_0',['CantidadIntegrantes',['../class_modelo_1_1_gasto_grupo_usuario.html#a9c7ebe7581da38b51c8838391ddb9da4',1,'Modelo::GastoGrupoUsuario']]],
  ['creadorid_1',['CreadorId',['../class_modelo_1_1_grupo.html#a74ec02452b96df92493a78d7f83c4bc7',1,'Modelo::Grupo']]]
];
