var namespace_gestor_datos_1_1_interfaces =
[
    [ "IGestorDatosGastos", "interface_gestor_datos_1_1_interfaces_1_1_i_gestor_datos_gastos.html", "interface_gestor_datos_1_1_interfaces_1_1_i_gestor_datos_gastos" ],
    [ "IGestorDatosGrupos", "interface_gestor_datos_1_1_interfaces_1_1_i_gestor_datos_grupos.html", "interface_gestor_datos_1_1_interfaces_1_1_i_gestor_datos_grupos" ],
    [ "IGestorDatosUsuario", "interface_gestor_datos_1_1_interfaces_1_1_i_gestor_datos_usuario.html", "interface_gestor_datos_1_1_interfaces_1_1_i_gestor_datos_usuario" ]
];